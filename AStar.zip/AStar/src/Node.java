import java.util.PriorityQueue;

public class Node implements Comparable<Node>{
	int x;
	int y;
	int g;
	int h[][];
	int f;
	int cost;
	int estimatedCost;
	Node previous;
	int gScore;
	int fScore;

	public Node(int x, int y, int cost, int estimatedCost) {
        this.x = x;
        this.y = y;
        this.cost = cost;
        this.estimatedCost = estimatedCost;
    }

    public Node(int x, int y, int cost, int estimatedCost, Node previous) {
        this.x = x;
        this.y = y;
        this.cost = cost;
        this.estimatedCost = estimatedCost;
        this.previous = previous;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getGScore() {
        return gScore;
    }

    public void setGScore(int gScore) {
        this.gScore = gScore;
    }

    public int getFScore() {
        return fScore;
    }

    public void setFScore(int fScore) {
        this.fScore = fScore;
    }

    @Override
    public int compareTo(Node other) {
        return Integer.compare(this.fScore, other.fScore);
    }


    public int getDirection(Node from, Node to) {
    	if (from.getX() - to.getX() == 1) {
            return 0;
        } else if (from.getY() - to.getY() == 1) {
            return 3;
        } else if (to.getX() - from.getX() == 1) {
            return 2;
        } else {
            return 1;
        }
    }
    

   

}