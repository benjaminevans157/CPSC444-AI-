
public class IllegalMoveException extends Exception{

}
