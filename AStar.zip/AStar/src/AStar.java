import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;

public class AStar {
	private Tracker tracker;
	private char[][] map;
    private int[][] h;
    private PriorityQueue<Node> queue;
    private Map<Integer, Node> visited;
    private static int goalX;
    private static int goalY;
    private int startX;
    private int startY;
    int current[][];
    ArrayList<Node> path;
    public AStar(char[][] map) {
        path = new ArrayList<>();
        this.tracker = new Tracker(map);
        this.h = new int[map.length][map[0].length];
        this.queue = new PriorityQueue<Node>();
        this.visited = new HashMap<Integer, Node>();
        this.map = map;
        //int[][] h = {{0, 1, 2, 3}};
        for (int i = 0; i < h.length; i++) {
            for (int j = 0; j < h[0].length; j++) {
                if (map[i][j] == 'G') {
                    goalX = i;
                    goalY = j;
                }
            }
        }
        for (int i = 0; i < h.length; i++) {
            for (int j = 0; j < h[0].length; j++) {
                if (map[i][j] == 'S') {
                    startX = i;
                    startY = j;
                }
            }
        }
    }

    public int stop() {
        return path.size()-1;
    }
    public int estimatedCost(int currentX, int currentY, int goalX, int goalY) {
        return Math.abs(currentX - goalX) + Math.abs(currentY - goalY);
    }
    public List<Node> getNeighbors(Node currentNode, char[][] map) {
        int row = currentNode.x;
        int col = currentNode.y;
        List<Node> neighbors = new ArrayList<>();

        // Check if the neighbor node exists and is not a wall
        if (row > 0 && map[row - 1][col] != 'W') {
            Node upNode = new Node(row - 1, col, currentNode.g + 1, manhattanDistance(row - 1, col));
            neighbors.add(upNode);
        }

        if (col < map[0].length - 1 && map[row][col + 1] != 'W') {
            Node rightNode = new Node(row, col + 1, currentNode.g + 1, manhattanDistance(row, col + 1));
            neighbors.add(rightNode);
        }

        if (row < map.length - 1 && map[row + 1][col] != 'W') {
            Node downNode = new Node(row + 1, col, currentNode.g + 1, manhattanDistance(row + 1, col));
            neighbors.add(downNode);
        }

        if (col > 0 && map[row][col - 1] != 'W') {
            Node leftNode = new Node(row, col - 1, currentNode.g + 1, manhattanDistance(row, col - 1));
            neighbors.add(leftNode);
        }

        return neighbors;
    }

    static int manhattanDistance(int x1, int y1) {
        
			try {
				return Math.abs(x1 - goalX) + Math.abs(y1 - goalY);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			return 0;
		
    }
    // your function for running the A* algorithm
    // don't put all code in this one method
    // use helper functions
    public int start() {
    	final int[] dx = {-1, 0, 1, 0};
    	final int[] dy = {0, 1, 0, -1};

    	this.map = map;
        this.startX = startX;
        this.startY = startY;
        this.goalX = goalX;
        this.goalY = goalY;
        // Find the start location (S)
        for (int i = 0; i < map.length; i++) {
            for (int j = 0; j < map[0].length; j++) {
                if (map[i][j] == 'S') {
                    startX = i;
                    startY = j;
                    break;
                }
            }
        }

        // Find the goal location (G)
        for (int i = 0; i < map.length; i++) {
            for (int j = 0; j < map[0].length; j++) {
                if (map[i][j] == 'G') {
                    goalX = i;
                    goalY = j;
                    break;
                }
            }
        }
            /// Create a priority queue to store the nodes to visit
        PriorityQueue<Node> list = new PriorityQueue<>();

     // Add the starting node to the queue
     list.add(new Node(startX, startY, 0, manhattanDistance(startX, startY)));

     // Create a 2D array to keep track of the visited nodes
     boolean[][] visited = new boolean[map.length][map[0].length];
     // Loop until the priority queue is empty
     while (!list.isEmpty()) {
         // Get the node with the lowest estimated cost
         Node current = list.poll();
        
         // Check if the current node is the goal
         if (current.x == goalX && current.y == goalY) {
             

             // Backtrack from the goal to the start to get the path
             while (current != null) {
                 path.add(current);
                 current = current.previous;
             }

             // Reverse the path to get the correct order
             Collections.reverse(path);

             if (path.size() > 0) {
            	    return path.size()-1;
            	} else {
            	    return 0;
            	}
         }

         // Mark the current node as visited
         visited[current.x][current.y] = true;

         // Check the four neighbors (up, right, down, left)
         for (int i = 0; i < 4; i++) {
             int newX = current.x + dx[i];
             int newY = current.y + dy[i];

             // Check if the new location is within the map bounds and not a wall
             if (newX >= 0 && newX < map.length && newY >= 0 && newY < map[0].length && map[newX][newY] != '#' && !visited[newX][newY]) {
                 // Calculate the cost for the new location
                 int cost = current.cost + 1;

                 // Calculate the estimated cost for the new location
                 int estimatedCost = cost + manhattanDistance(newX, newY);

                 // Add the new location to the queue
                 list.add(new Node(newX, newY, cost, estimatedCost, current));
             }
         }
     }

     // Return null if no path was found
     return 0;
        }
    

    }
